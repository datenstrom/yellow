---
Title: Made for people
Published: 2020-12-06
Author: Datenstrom
Layout: blog
Tag: Example
---
Datenstrom Yellow is for people who make small websites. The focus is on people and that it's useful for you. Change everything as you like. You can edit your blog in a web browser or on your computer. There's no admin panel, nothing that gets in your way.
