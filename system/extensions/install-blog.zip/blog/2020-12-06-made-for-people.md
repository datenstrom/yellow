---
Title: Made for people
Published: 2020-12-06
Author: Datenstrom
Layout: blog
Tag: Example
---
Datenstrom Yellow is for people who make small websites. Create small web pages, blogs and wikis. The focus is on people and that it's useful for you. No database, no admin panel, nothing that gets in your way. You make your website, we take care of the rest.
