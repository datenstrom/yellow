---
Title: Wiki
Layout: wiki-start
LayoutNew: wiki
Tag: Example
---
Datenstrom Yellow is for people who make small websites. Installing is unzipping one file and you are ready to go. The most important things for small websites are included. You can add features, themes and languages. Datenstrom Yellow works as content management system and static site generator.
