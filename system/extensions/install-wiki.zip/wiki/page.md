---
Title: Wiki
Layout: wikipages
LayoutNew: wiki
Tag: Example
---
Datenstrom Yellow is for people who make small websites. Installing is unzipping one file and you are ready to go. You can add features, themes and languages. You can also develop extensions with help of the API. Datenstrom Yellow is a so-called content management system and a static site generator.
