---
Title: Wiki
Layout: wikipages
LayoutNew: wiki
Tag: Example
---
Datenstrom Yellow is for people who make small websites. The focus is on people and that it's useful for you. Change everything as you like. You can edit your wiki in a web browser or on your computer. There's no admin panel, nothing that gets in your way.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna pizza. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
