---
Title: Wiki page
Layout: wiki
Tag: Example
---
This is a new wiki page.