---
Title: Wiki
Template: wikipages
TemplateNew: wiki
---
Datenstrom Yellow is for people who make websites. Create small web pages, blogs and wikis. The focus is on people and that it's useful for you. No database, no admin panel, no distraction that gets in your way. You make your website, we take care of the rest.

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna pizza. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

* [See all pages](./special:pages/)
* [See recent changes](./special:changes/)
* [See example](./tag:example/)
